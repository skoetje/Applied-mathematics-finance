classdef TradingRobot < AutoTrader
    properties
    end

    methods
        function HandleDepthUpdate(aBot, ~, aDepth)
        end
    end
end

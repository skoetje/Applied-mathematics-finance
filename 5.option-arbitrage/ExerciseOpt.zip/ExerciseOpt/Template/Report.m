function Report(aTrades, aSpot)
    % Report cash and position given the trades and a spot at the time of expiry
    fprintf('...\n')
end

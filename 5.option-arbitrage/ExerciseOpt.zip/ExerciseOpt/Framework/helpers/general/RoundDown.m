function theRoundedNumber = RoundDown(aNumber, aRoundTo)

theRoundedNumber = aRoundTo * floor(aNumber / aRoundTo);

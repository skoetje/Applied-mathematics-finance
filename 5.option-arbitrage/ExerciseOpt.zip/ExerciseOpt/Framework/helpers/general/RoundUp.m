function theRoundedNumber = RoundUp(aNumber, aRoundTo)

theRoundedNumber = aRoundTo * ceil(aNumber / aRoundTo);

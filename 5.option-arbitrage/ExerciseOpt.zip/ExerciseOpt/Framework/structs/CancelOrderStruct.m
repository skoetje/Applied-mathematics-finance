function theStruct = CancelOrderStruct(aISIN, aExchangeOrderId, aAutoTraderId)

theStruct.ISIN            = aISIN;
theStruct.exchangeOrderId = aExchangeOrderId;
theStruct.autoTraderId    = aAutoTraderId;
